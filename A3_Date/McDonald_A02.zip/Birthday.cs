﻿using System;
// if you want to use the instructor's version of "MyDate":
using Date_SOLUTION; // leave this line UNcommented
// using A3_Date_StudentWork;  // and comment this line out.

//If you want to use your version of "MyDate" then comment out using Date_SOLUTION; and UNcomment using A3_Date_StudentWork;

namespace A3_Date
{
    class Birthday
    {
        static void Main(string[] args)
        {
            //MyDate today = new MyDate();
            int todayMonth;
            int todayDay;

            //MyDate bday = new MyDate();
            int bdayMonth;
            int bdayDay;
            int total =0;
            //MyDate today = new MyDate();
            //int todayMonth;
            //int todayDay;

            //MyDate bday = new MyDate();
            //int bdayMonth;
            //int bdayDay;
      
            Console.WriteLine("What is today's month?");
            Int32.TryParse(Console.ReadLine(), out todayMonth);
            Console.WriteLine("What is today's day?");
            Int32.TryParse(Console.ReadLine(), out todayDay);
            Console.WriteLine("What is your birthday month?");
            Int32.TryParse(Console.ReadLine(), out bdayMonth);
            Console.WriteLine("What is your birthday day?");
            Int32.TryParse(Console.ReadLine(), out bdayDay);

            MyDate bday = new MyDate(bdayMonth, bdayDay);
            MyDate today = new MyDate(todayMonth, todayDay);


           // today.setDate(todayMonth, todayDay);
            //bday.setDate(bdayMonth, bdayDay);
            //bday.daysInMonth();

            
            Console.WriteLine("There are {0} days in month #{1}",bday.daysInMonth(),bdayMonth);

            if (today.equals(bday) == true)
                Console.WriteLine("Happy birthday!");
            else if (today.equals(bday)==false)
            {
                total = 0;
                for (; todayDay < bdayDay; todayDay++)
                {
                    today.nextDay();
                    total++;
                }
                for (; todayMonth<=bdayMonth; todayMonth++)
                {
                    if (todayMonth == bdayMonth)
                        continue;
                    else
                    total += today.daysInMonth();
                }
                
            }


                Console.WriteLine("Number of days until {0}: {1}", bday.toString(), total);
                //COUNT NUMBER OF DAYS LEFT IN THIS MONTH
                //THEN GET THE SUM OF THE DAYS IN THE MONTHS IN BETWEEN THIS MONTH AND THE BIRTHMONTH
                //THEN ADD THE REMAINING DAYS UNTIL tODAYDAY AND bDAYDAY ARE EUQUAL
                //PRINT OUT "Number of days until birthday: bday.toString(); THEN THE total NUMBER OF DAYS UNTIL
            
                

        }
        
    }


    //public class MyDate
    //{
    //    private int day;
    //    private int[] daysPerMonth = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    //    private int month;

    //    public MyDate(int m, int d)
    //    {
    //        month = m;
    //        day = d;
    //    }
    //    public MyDate()
    //    {

    //    }

    //    public int daysInMonth()
    //    {
    //        return daysPerMonth[month - 1];
    //    }

    //    public bool equals(MyDate d)
    //    {
    //        return ((month == d.month) && (day == d.day));
    //    }

    //    public int getDay()
    //    {
    //        return day;
    //    }

    //    public int getMonth()
    //    {
    //        return month;
    //    }

    //    public void nextDay()
    //    {
    //        if ((day + 1) > daysInMonth())
    //        {
    //            month = (month % 12) + 1;
    //            day = 1;
    //        }
    //        else
    //        {
    //            day++;
    //        }
    //    }

    //    public void setDate(int m, int d)
    //    {
    //        month = m;
    //        day = d;
    //    }

    //    public string toString()
    //    {
    //        return (month + "/" + day);
    //    }
    //}
}




