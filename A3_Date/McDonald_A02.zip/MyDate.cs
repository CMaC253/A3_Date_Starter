﻿using System;

namespace A3_Date_StudentWork
{

    //THIS CLASS HAS NOT BEEN IMPLEMENTED YET
    //PLEASE GO TO BIRTHDAY.CS

    public class MyDate
    {
        private int day;
        private int[] daysPerMonth = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        private int month;

        public MyDate(int m, int d)
        {
            month = m;
            day = d;
        }
        public MyDate()
        {

        }

        public int daysInMonth()
        {
            return daysPerMonth[month - 1];
        }

        public bool equals(MyDate d)
        {
            return ((month == d.month) && (day == d.day));
        }

        public int getDay()
        {
            return day;
        }

        public int getMonth()
        {
            return month;
        }

        public void nextDay()
        {
            if ((day + 1) > daysInMonth())
            {
                month = (month % 12) + 1;
                day = 1;
            }
            else
            {
                day++;
            }
        }

        public void setDate(int m, int d)
        {
            month = m;
            day = d;
        }

        public string toString()
        {
            return (month + "/" + day);
        }
    }

    //class MyDate
    //{
    //    private int month, day;
    //    private int[] daysPerMonth = new int[] { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    //    public MyDate(int newMonth, int newDay)
    //    {
    //        newMonth = month;
    //        newDay = day;
    //    }
    //    public MyDate()
    //    {
    //            month = 0;
    //            day = 0;
    //    }
    //    public int daysInMonth()
    //    {
    //        return daysPerMonth[month - 1];
    //    }
    //    public bool equals(MyDate d)
    //    {
    //        return ((month == d.month) && (day == d.day));
    //    }
    //    public int getMonth()
    //    {  
    //        return month;
    //    }
    //    public int getDay()
    //    {
    //        return day;
    //    }
    //    public void nextDay()
    //    {
    //        if ((day + 1) > daysInMonth())
    //        {
    //            month = (month % 12) + 1;
    //            day = 1;
    //        }
    //        else
    //        {
    //            day++;
    //        }
    //    }
    //    public void setDate(int newMonth, int newDay)
    //    {
    //        newMonth = month;
    //        newDay = day;
    //    }
    //    public string toString()
    //    {
    //        return (month + "/" + day);
    //    }




    //}
}
